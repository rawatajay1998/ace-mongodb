export const countyApiBaseUrl = "https://countriesnow.space/api/v0.1";
