export const endpoints = {
  getAllCities: "countries",
};
