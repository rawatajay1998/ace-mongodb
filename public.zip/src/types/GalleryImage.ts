export type GalleryImage = {
  id: string;
  url: string;
};
