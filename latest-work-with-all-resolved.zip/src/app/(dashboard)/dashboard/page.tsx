import React from "react";

const DashboardPage = async () => {
  return <div>DashboardPage</div>;
};

export default DashboardPage;
