import React from "react";
import AddAgentForm from "./AddAgentForm";

const AddAgent = () => {
  return <AddAgentForm />;
};

export default AddAgent;
