// import PropertyModel from "@/models/property.model";
// import connectDB from "@/lib/db";

// export async function getPropertyBySlug(
//   slug: string
// ): Promise<Property | null> {
//   await connectDB();
//   const property = await PropertyModel.findOne({ slug }).lean();
//   return property as Property | null;
// }
